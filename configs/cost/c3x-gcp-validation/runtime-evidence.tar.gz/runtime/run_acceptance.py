#!/usr/bin/env python3
"""Import real normalized products and exercise unchanged C3X locally.
No cloud calls, credentials, Terraform execution, or pricing substitutions.
All result files are confined to this runtime directory. No automatic cleanup.
"""
import argparse,datetime,hashlib,json,os,pathlib,shutil,subprocess,time
R=pathlib.Path(__file__).resolve().parent
ENV={'PATH':'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','HOME':str(R/'home')}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def inspect_contract(path):
 seen=set();rows=prices=duplicates=0
 with path.open() as f:
  for line in f:
   rows+=1
   try:p=json.loads(line)
   except Exception:raise ValueError(f'invalid NDJSON at line {rows}') from None
   if not isinstance(p,dict) or p.get('vendorName')!='gcp' or not p.get('productHash') or not p.get('sku'):raise ValueError(f'invalid identity at line {rows}')
   if not isinstance(p.get('attributes'),dict) or not all(isinstance(k,str) and isinstance(v,str) for k,v in p['attributes'].items()):raise ValueError(f'attributes must be string map at line {rows}')
   if not isinstance(p.get('prices'),list):raise ValueError(f'prices must be array at line {rows}')
   for price in p['prices']:
    if not isinstance(price,dict) or not isinstance(price.get('USD'),str):raise ValueError(f'price USD must be string at line {rows}')
   for key in ('region','service','productFamily'):
    if not isinstance(p.get(key),str):raise ValueError(f'missing string field at line {rows}')
   prices+=len(p['prices'])
   if p['productHash'] in seen:duplicates+=1
   seen.add(p['productHash'])
 if rows==0:raise ValueError('empty product file')
 return {'input_rows':rows,'unique_product_hashes':len(seen),'duplicate_hash_rows':duplicates,'input_price_rows':prices,'sha256':sha(path)}
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--products',required=True,type=pathlib.Path);ap.add_argument('--skip-no-price-control',action='store_true');a=ap.parse_args()
 source=a.products.resolve()
 if not source.is_file():raise SystemExit('products file unavailable; nothing run')
 contract=inspect_contract(source)
 h=json.loads((R/'handles.json').read_text())
 out=R/('run-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));out.mkdir()
 def run(args,name=None,check=True,timeout=90):
  start=time.monotonic()
  try:
   p=subprocess.run(args,cwd=R,env=ENV,capture_output=True,text=True,timeout=timeout)
   rc,stdout,stderr=p.returncode,p.stdout,p.stderr
  except subprocess.TimeoutExpired as e:
   rc=124;stdout=e.stdout or '';stderr=e.stderr or ''
   if isinstance(stdout,bytes):stdout=stdout.decode(errors='replace')
   if isinstance(stderr,bytes):stderr=stderr.decode(errors='replace')
   stderr+='\nharness timeout\n'
  rec={'command':args,'rc':rc,'seconds':round(time.monotonic()-start,3),'stdout':stdout,'stderr':stderr}
  with (out/'commands.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
  if name:
   (out/(name+'.stdout')).write_text(stdout);(out/(name+'.stderr')).write_text(stderr)
   rec['stdout_file']=name+'.stdout';rec['stderr_file']=name+'.stderr'
  if check and rc:raise RuntimeError(f'command failed rc={rc}; see {out}/commands.jsonl')
  return rec
 def dex(role,args,**kw):return run(['docker','exec',h[role],*args],**kw)
 def quote(kind,name,usage=False,label=None):
  label=label or name+'.'+kind+('.usage' if usage else '')
  args=['/trial/c3x-cli','estimate','--path','/trial/'+('fixtures' if kind=='tf-json' else 'derived-hcl')+'/'+name,'--pricing-endpoint',h['endpoint'],'--region','us-west1','--currency','USD','--no-cache','--no-remote-modules','--show-skipped','--format','json','-vv']
  if usage:args+=['--usage','/trial/usage.yml']
  p=dex('cli',args,name=label,check=False,timeout=90)
  return {'fixture':name,'format':kind,'supplied_usage':usage,'rc':p['rc'],'stdout_file':p['stdout_file'],'stderr_file':p['stderr_file'],'command':p['command'],'unsupported_tf_json':kind=='tf-json' and 'no .tf files' in (p['stdout']+p['stderr'])}
 # Verify only our exact, labeled resources are touched, and no extra network or mounted state exists.
 topology=[]
 for role in ['db','api','cli']:
  d=json.loads(run(['docker','inspect',h[role]])['stdout'])[0]
  assert h[role].startswith('isaac-gcp-verify-') and d['Config']['Labels'].get('isaac.cost.trial')=='gcp-verify'
  assert list(d['NetworkSettings']['Networks'])==[h['network']]
  assert not d['HostConfig']['PortBindings'] and not any(m['Type'] in ('volume','bind') for m in d['Mounts'])
  assert d['HostConfig']['Memory']>0 and d['HostConfig']['NanoCpus']>0
  topology.append({'role':role,'id':d['Id'],'image':d['Image'],'networks':list(d['NetworkSettings']['Networks']),'mounts':d['Mounts']})
 assert json.loads(run(['docker','network','inspect',h['network']])['stdout'])[0]['Internal']
 (out/'topology.json').write_text(json.dumps(topology,indent=2))
 for role in ['api','cli']:dex(role,['/trial/net-helper','isolation'],name=role+'-isolation-before')
 dex('cli',['/trial/net-helper','get','http://'+h['api']+':4000/healthz'],name='health-before')
 # Immutable staging copy avoids a restrictive parent mode blocking container user 65534.
 staged=R/'products.ndjson';shutil.copyfile(source,staged);staged.chmod(0o644)
 assert sha(staged)==contract['sha256'],'source changed while copying'
 (out/'input-contract.json').write_text(json.dumps(contract,indent=2))
 run(['docker','cp',str(staged),h['api']+':/trial/products.ndjson'])
 imp=dex('api',['/trial/trial-import'],name='import',timeout=660)
 imported=json.loads(imp['stdout']);assert imported['status']=='ok'
 assert imported['lines']==contract['input_rows'] and imported['database_products']==contract['unique_product_hashes']
 dex('db',['psql','-U','postgres','-d','pricing','-Atc',"SELECT json_build_object('products',count(*),'price_rows',sum(jsonb_array_length(prices))) FROM products"],name='database-counts')
 # Verify the setup projections still derive from the current public fixtures. No source writes.
 from setup import projection
 manifest=json.loads((R/'fixtures-manifest.json').read_text());assert len(manifest)==4
 for m in manifest:
  name=m['fixture'];src=pathlib.Path('/workspaces/IsaacAutomator/configs/cost/fixtures')/name/'main.tf.json'
  assert sha(src)==m['json_sha256'] and sha(R/'fixtures'/name/'main.tf.json')==m['json_sha256']
  assert (R/'derived-hcl'/name/'main.tf').read_text()==projection(json.loads(src.read_text()))
 assert sha(R/'usage.yml')==sha(pathlib.Path('/workspaces/IsaacAutomator/configs/cost/infracost-usage.example.yml'))
 for folder in ['fixtures','derived-hcl']:run(['docker','cp',str(R/folder),h['cli']+':/trial/'+folder])
 run(['docker','cp',str(R/'usage.yml'),h['cli']+':/trial/usage.yml'])
 helpout=dex('cli',['/trial/c3x-cli','estimate','--help'],name='estimate-help')['stdout']
 usage_supported='--usage string' in helpout
 dex('cli',['/trial/net-helper','get','http://'+h['api']+':4000/catalog'],name='served-catalog')
 results=[]
 try:
  for kind in ['tf-json','hcl']:
   for m in manifest:
    results.append(quote(kind,m['fixture']))
    (out/'fixture-results.json').write_text(json.dumps(results,indent=2))
  if usage_supported:
   for m in manifest:
    results.append(quote('hcl',m['fixture'],True))
    (out/'fixture-results.json').write_text(json.dumps(results,indent=2))
  control=None
  if not a.skip_no_price_control:
   run(['docker','stop','--time','10',h['api']])
   try:
    unavailable=dex('cli',['/trial/net-helper','get','http://'+h['api']+':4000/healthz'],name='control-api-unavailable',check=False)
    assert unavailable['rc']!=0
    control=quote('hcl','g4-standard-48-standard',label='no-price-api-stopped')
   finally:
    run(['docker','start',h['api']])
    for _ in range(20):
     health=dex('cli',['/trial/net-helper','get','http://'+h['api']+':4000/healthz'],name='health-restored',check=False)
     if health['rc']==0:break
     time.sleep(1)
    else:raise RuntimeError('API did not become healthy after control')
  for role in ['api','cli']:dex(role,['/trial/net-helper','isolation'],name=role+'-isolation-after')
  assert len(results)==(12 if usage_supported else 8)
  summary={'status':'EXECUTED_REQUIRES_PRICE_ACCEPTANCE_REVIEW','results':results,'usage_flag_supported':usage_supported,'control':control,'input':contract,'notes':['Original .tf.json results are distinct from derived HCL; nonzero quote exits are evidence, not harness failures.','C3X defaults to 730 monthly hours; fixture Flex max_run_duration is 3600 seconds (one hour), not the same cost scenario. Supplied usage also requests monthly_hrs 730; verify actual consumed attribute, do not assume compatible names.','Do not accept zero or live labels as proof of a price. Inspect response audit and G4, Flex, GPU, Hyperdisk mappings and reference-region fallbacks.','No provider plugins/modules are installed: no Terraform command is executed; all pricing targets are the isolated local proxy.'], 'genuine_prices_accepted':None}
  (out/'summary.json').write_text(json.dumps(summary,indent=2))
 finally:
  run(['docker','logs',h['cli']],name='http-routing',check=False)
  run(['docker','logs',h['api']],name='api-logs',check=False)
 print(json.dumps({'output':str(out),'quotes_recorded':len(results),'products':imported['database_products'],'services_left_running':True}))
if __name__=='__main__':main()
