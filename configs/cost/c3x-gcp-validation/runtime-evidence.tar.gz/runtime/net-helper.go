// Test-only transport recorder and network probe, no pricing logic.
package main
import("bytes";"context";"encoding/json";"fmt";"io";"net";"net/http";"net/http/httputil";"net/url";"os";"time")
func main(){
 switch os.Args[1] {
 case "proxy":
  u,err:=url.Parse(os.Args[2]);if err!=nil{panic("invalid target")};p:=httputil.NewSingleHostReverseProxy(u)
  p.ModifyResponse=func(r *http.Response)error{b,e:=io.ReadAll(r.Body);if e!=nil{return e};r.Body=io.NopCloser(bytes.NewReader(b));json.NewEncoder(os.Stdout).Encode(map[string]any{"event":"response","method":r.Request.Method,"path":r.Request.URL.String(),"status":r.StatusCode,"body":string(b)});return nil}
  err=http.ListenAndServe(":4001",http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){b,_:=io.ReadAll(r.Body);r.Body=io.NopCloser(bytes.NewReader(b));json.NewEncoder(os.Stdout).Encode(map[string]string{"event":"request","method":r.Method,"path":r.URL.String(),"body":string(b),"forward_to":u.String()});p.ServeHTTP(w,r)}));if err!=nil{os.Exit(1)}
 case "get":
  c:=http.Client{Timeout:5*time.Second};r,e:=c.Get(os.Args[2]);if e!=nil{fmt.Println("local_http_unavailable");os.Exit(1)};defer r.Body.Close();io.Copy(os.Stdout,r.Body);if r.StatusCode!=200{os.Exit(1)}
 case "isolation":
  ok:=true
  for _,host:=range []string{"pricing.c3x.dev","registry.terraform.io","cloudbilling.googleapis.com"}{ctx,cancel:=context.WithTimeout(context.Background(),3*time.Second);_,err:=net.DefaultResolver.LookupHost(ctx,host);cancel();blocked:=err!=nil;json.NewEncoder(os.Stdout).Encode(map[string]any{"type":"dns","target":host,"blocked":blocked});ok=ok&&blocked}
  c,err:=net.DialTimeout("tcp","1.1.1.1:443",3*time.Second);if err==nil{c.Close()};json.NewEncoder(os.Stdout).Encode(map[string]any{"type":"tcp","target":"1.1.1.1:443","blocked":err!=nil});ok=ok&&err!=nil;if !ok{os.Exit(1)}
 default:os.Exit(2)
 }
}
