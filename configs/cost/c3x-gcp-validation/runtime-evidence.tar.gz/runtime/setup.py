#!/usr/bin/env python3
"""Credential-free disposable local setup; never imports or estimates."""
import hashlib,json,os,pathlib,shutil,subprocess,time,uuid
R=pathlib.Path(__file__).resolve().parent
ENV={'PATH':'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','HOME':str(R/'home')}
def run(args,check=True,timeout=60):
 p=subprocess.run(args,cwd=R,env=ENV,text=True,capture_output=True,timeout=timeout)
 rec={'command':args,'rc':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 with (R/'setup-commands.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
 if check and p.returncode:raise RuntimeError(rec)
 return p

def val(x):
 if isinstance(x,dict):return '{ '+', '.join(json.dumps(k)+' = '+val(v) for k,v in x.items())+' }'
 if isinstance(x,list):return '['+', '.join(map(val,x))+']'
 return json.dumps(x)
def attrs(d,indent='  '):
 out=[]
 for k,v in d.items():
  if isinstance(v,dict) and k not in ['metadata','required_providers','labels']:
   out.append(indent+k+' {\n'+attrs(v,indent+'  ')+indent+'}')
  else:out.append(indent+k+' = '+val(v))
 return '\n'.join(out)+'\n'
def projection(d):
 parts=[]
 for kind,groups in d.items():
  if kind=='terraform':parts.append('terraform {\n'+attrs(groups)+'}')
  elif kind=='provider':
   for name,body in groups.items():parts.append('provider '+json.dumps(name)+' {\n'+attrs(body)+'}')
  elif kind=='resource':
   for typ,items in groups.items():
    for name,body in items.items():parts.append('resource '+json.dumps(typ)+' '+json.dumps(name)+' {\n'+attrs(body)+'}')
  else:raise ValueError('unsupported projection top-level')
 return '\n\n'.join(parts)+'\n'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 if (R/'handles.json').exists():raise SystemExit('already provisioned: refusing duplicate setup')
 src=pathlib.Path('/workspaces/IsaacAutomator/configs/cost')
 shutil.copytree(src/'fixtures',R/'fixtures')
 shutil.copy2(src/'infracost-usage.example.yml',R/'usage.yml')
 fixtures=[]
 for f in sorted((R/'fixtures').glob('*/main.tf.json')):
  text=projection(json.loads(f.read_text())); old=pathlib.Path('/tmp/isaac-selfhost-trials/c3x/derived-hcl')/f.parent.name/'main.tf'
  target=R/'derived-hcl'/f.parent.name/'main.tf';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
  fixtures.append({'fixture':f.parent.name,'json_sha256':sha(f),'hcl_sha256':sha(target),'old_hcl_matches_current_projection':old.read_text()==text,'source_json_semantically_matches_previous':json.loads(f.read_text())==json.loads((pathlib.Path('/tmp/isaac-selfhost-trials/c3x/fixtures')/f.parent.name/'main.tf.json').read_text())})
 assert len(fixtures)==4
 (R/'fixtures-manifest.json').write_text(json.dumps(fixtures,indent=2))
 prefix='isaac-gcp-verify-'+uuid.uuid4().hex[:8]
 h={'prefix':prefix,'network':prefix+'-net','db':prefix+'-db','api':prefix+'-api','cli':prefix+'-cli','label':'isaac.cost.trial=gcp-verify','image':'postgres:16-bookworm'}
 h['endpoint']='http://'+h['cli']+':4001/graphql'
 h['database_url']='postgres://postgres@'+h['db']+':5432/pricing?sslmode=disable'
 (R/'handles.json').write_text(json.dumps(h,indent=2))
 run(['docker','network','create','--internal','--label',h['label'],h['network']])
 base=['--label',h['label'],'--network',h['network'],'--dns','127.0.0.1','--cpus','1','--pids-limit','256','--security-opt','no-new-privileges','--restart','no']
 run(['docker','run','-d','--pull','never','--name',h['db'],*base,'--memory','2g','--memory-swap','2g','--tmpfs','/var/lib/postgresql/data:rw,size=1536m','-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB=pricing','--health-cmd','pg_isready -U postgres -d pricing','--health-interval','2s','--health-timeout','2s','--health-retries','30',h['image']])
 for _ in range(45):
  if run(['docker','inspect','--format','{{.State.Health.Status}}',h['db']]).stdout.strip()=='healthy':break
  time.sleep(1)
 else:raise RuntimeError('DB not healthy; no API start')
 for role,binary,args in [('api','pricing-api',['serve']),('cli','net-helper',['proxy','http://'+h['api']+':4000'])]:
  extras=['-e','GOMAXPROCS=1','-e','HOME=/tmp/trial-home','-e','XDG_CACHE_HOME=/tmp/trial-cache','-e','XDG_CONFIG_HOME=/tmp/trial-config']
  if role=='api':extras+=['-e','DATABASE_URL='+h['database_url']]
  run(['docker','create','--pull','never','--name',h[role],*base,'--memory','512m','--memory-swap','512m','--cap-drop','ALL','--user','65534:65534','--tmpfs','/tmp:rw,size=128m,mode=1777','--tmpfs','/var/lib/postgresql/data:rw,size=1m','--workdir','/trial',*extras,'--entrypoint','/trial/'+binary,h['image'],*args])
  for b in ['net-helper',binary]+(['trial-import'] if role=='api' else ['c3x-cli']):
   run(['docker','cp',str(R/b),h[role]+':/trial/'+b])
  run(['docker','start',h[role]])
 health=[]
 for _ in range(30):
  p=run(['docker','exec',h['cli'],'/trial/net-helper','get','http://'+h['api']+':4000/healthz'],False)
  if p.returncode==0:health.append({'service':'api','health':p.stdout});break
  time.sleep(1)
 else:raise RuntimeError('API failed health')
 health.append({'service':'db','health':run(['docker','exec',h['db'],'pg_isready','-U','postgres','-d','pricing']).stdout})
 health.append({'service':'audit-proxy','health':run(['docker','exec',h['cli'],'/trial/net-helper','get','http://localhost:4001/healthz']).stdout})
 run(['docker','exec',h['cli'],'/trial/c3x-cli','estimate','--help'])
 iso={}
 for role in ['api','cli']:
  iso[role]=run(['docker','exec',h[role],'/trial/net-helper','isolation']).stdout
 topology=[]
 for role in ['db','api','cli']:
  d=json.loads(run(['docker','inspect',h[role]]).stdout)[0]
  # Keep only bounded non-secret operational state, not image environment.
  topology.append({'role':role,'name':h[role],'image_id':d['Image'],'state':d['State']['Status'],'ports':d['HostConfig']['PortBindings'],'mounts':d['Mounts'],'networks':list(d['NetworkSettings']['Networks']),'memory':d['HostConfig']['Memory'],'nano_cpus':d['HostConfig']['NanoCpus'],'labels':d['Config']['Labels']})
  assert not d['HostConfig']['PortBindings'] and not any(m['Type'] in ('volume','bind') for m in d['Mounts'])
  assert list(d['NetworkSettings']['Networks'])==[h['network']]
 internal=json.loads(run(['docker','network','inspect',h['network']]).stdout)[0]['Internal'];assert internal
 count=run(['docker','exec',h['db'],'psql','-U','postgres','-d','pricing','-Atc','SELECT COUNT(*) FROM products']).stdout.strip();assert count=='0'
 receipt={'status':'READY_NOT_QUOTED','health':health,'network_internal':internal,'isolation':iso,'database_products':count,'topology':topology,'binaries':{b:sha(R/b) for b in ['c3x-cli','pricing-api','trial-import','net-helper']},'fixtures':fixtures,'credentials':'none passed; build env allowlisted; services internal only','control':'runner stops API once and restarts in finally','usage':'--usage supported; supplied 0.1 resource_usage format accepted structurally; actual attribute consumption must be inspected from quotes. Monthly baseline 730h is NOT one-hour Flex max_run_duration.'}
 (R/'setup-receipt.json').write_text(json.dumps(receipt,indent=2))
 print(json.dumps({'handles':h,'health':health,'isolation':iso,'status':receipt['status']},indent=2))
if __name__=='__main__':main()
