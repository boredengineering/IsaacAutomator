# Completed: isolated C3X GCP catalog acceptance runtime

**Executed after parent authorized the completed catalog:** `run-20260913T172059Z/` contains actual importer and CLI receipts. Imported 3787 products / 4443 price rows. All four JSON inputs exited 1; all eight HCL inputs exited 0, but G4 acceptance FAILED: zero machine rates labeled live, Tesla T4 instead of RTX PRO 6000, and PD capacity instead of Hyperdisk. Standard/Flex totals were identical. API-stopped control exited 1 with HTTP 502, then API recovered healthy. See `verification.json` and run `quote-analysis.json`; services remain running for parent verification. Preparation-state fields below are historical, not the final database state.

## Parent invocation / reproducibility

```sh
/tmp/isaac-gcp-cost-validation/runtime/run_acceptance.py \
  --products /tmp/isaac-gcp-cost-validation/catalog/products.ndjson
```

The runner records results below `runtime/run-<UTC timestamp>/`. It does not fetch Google data, run Terraform, provision anything, change mappings, or accept prices automatically. Successful harness completion means execution evidence exists, NOT that G4/Flex/Hyperdisk pricing is correct. It runs all four original JSON directories, four exact HCL projections, four HCL cases with the supplied usage file, and one API-stopped negative control. The API is restarted in `finally`; the parent owns final cleanup. Individual quote failures are preserved rather than hiding subsequent cases.

## Running services

- Internal Docker network: `isaac-gcp-verify-77e5e4c2-net`
- PostgreSQL: `isaac-gcp-verify-77e5e4c2-db`
- Native patched API: `isaac-gcp-verify-77e5e4c2-api`, internal port 4000
- Native pinned CLI / transparent audit proxy: `isaac-gcp-verify-77e5e4c2-cli`, internal proxy port 4001
- Local CLI endpoint: `http://isaac-gcp-verify-77e5e4c2-cli:4001/graphql`
- Label on every owned container/network: `isaac.cost.trial=gcp-verify`

All three use the already-local `postgres:16-bookworm` image with `--pull never`; API/CLI override its entrypoint. DB health became healthy before API start. Actual API/proxy `/healthz` return `{"status":"ok"}`; CLI estimate help executes. All have CPU/memory/pid limits, no published ports, no bind mounts or volumes. PostgreSQL data is tmpfs (1536 MiB; DB memory limit 2 GiB), and API/CLI memory limits are 512 MiB each. Image-declared PGDATA volumes are overridden with tmpfs even on API/CLI. Trust auth is restricted to this disposable internal-only database. Docker image fallback: the old trial Go image tag was unavailable, so no pull/build was attempted for it.

Both API and CLI independently failed external DNS resolution for pricing.c3x.dev, registry.terraform.io, and cloudbilling.googleapis.com, and failed TCP to 1.1.1.1:443. The runner repeats these checks before and after estimation and verifies the exact single internal network, labels, memory/CPU bounds, and absence of bind/volume mounts. No inherited host environment is passed to subprocess builds or estimates. The helper/proxy does not add authentication, transforms no requests/responses, and includes full local request and response bodies in Docker logs.

## Exact input contract

Each nonempty NDJSON line is a Go `db.Product` serialized using its production JSON tags (no wrapper array, no pretty-printed multiline objects):

- `productHash`, `sku`, `vendorName`, `region`, `service`, `productFamily`: strings; vendor must be `gcp`; hash and SKU nonempty.
- `attributes`: JSON object with string values.
- `prices`: JSON array of production `db.Price` objects. Required encoded fields are `priceHash`, `unit`, `USD` (strings; USD is a decimal STRING, not a numeric JSON token).
- Optional price strings: `purchaseOption`, `startUsageAmount`, `endUsageAmount`, `description`, `termLength`, `termPurchaseOption`, `termOfferingClass`.

The runner copies the public product data into its own staging file, fixes only its filesystem read permission, and copies it to API `/trial/products.ndjson`. No product/price values are generated or rewritten. Native `trial-import` uses production `config.Load`, `db.New`, `RunMigrations`, and `UpsertProducts`, in 1000-row batches; max input line 16 MiB; total import context 10 minutes. It prints only numeric counts/status/fixed error stage, never product data or raw DB errors. Production upsert deduplicates by hash inside each batch (first row wins), and cross-batch duplicates update SKU/attributes/prices. No global import transaction: an error can leave earlier batches imported, but the runner immediately aborts before quotes. Use the initial empty DB for this acceptance; count validation catches unrelated prior rows.

The runner validates input shape, records source SHA-256/row/unique-hash/price counts, asserts importer row count and final DB unique-product count, and obtains SQL price-row counts. It does not demand a full worldwide catalog; parent controls scope/provenance. No catalog file was read or polled during preparation.

## Source/build fidelity

- API source copy: `api-source/`, from `/tmp/isaac-c3x-oauth-parent/replay`; only new `cmd/trial-import` harness added. Production DB/schema/normalization unchanged.
- Served API binary copied from `/tmp/isaac-c3x-oauth-parent/c3x-pricing-api`.
- CLI copied from previous trial; source HEAD is `21bc4dc26eb779b7ee18bd4cdcbb6986578b1703`, clean; binary SHA-256 matches its previous receipt (`f581209021a621f084fec70264ad8d7bea82cc80aaf79b6cf0ca711ea25bc37e`).
- Importer and network helper built with existing Go 1.26.8 and `/tmp/isaac-c3x-oauth/{gopath,cache,modcache}`, allowlisted environment, CGO disabled, GOPROXY=off, GOSUMDB=off, GOTOOLCHAIN=local. No credentials in build environment.
- Malformed-input decoder test first failed due to the missing implementation, then passed. Importer/DB/config tests pass. Native importer was exercised against actual PostgreSQL with absent input: rc 1, sanitized `input_open`, zero processed rows; DB remains at zero products. Successful real import intentionally awaits parent data.

## Fixtures and usage caveats

`fixtures-manifest.json` verifies exactly four public fixtures. Every existing HCL projection matches regeneration from the current JSON byte-for-byte; old JSON is semantically identical. `setup.py` documents the conservative JSON-to-HCL projection: identical attribute values and nested blocks, metadata/labels/provider requirements remain map attributes. Original fixtures are not edited. The runner re-verifies source hashes and projection text before quotes.

Original `.tf.json` input is tracked separately from HCL. Previous CLI rejected these directories as having no `.tf` files; this run records actual exits rather than assuming acceptance.

`--usage` exists. Supplied `infracost-usage.example.yml` has the accepted version `0.1` / `resource_usage` structure and is copied unmodified. Structurally accepted usage does not prove every attribute is consumed. C3X's `monthly_hours()` default is 730; supplied usage requests `monthly_hrs: 730`; Flex fixtures specify `max_run_duration.seconds: 3600` (one hour). These are different billing scenarios. No rescaling or assumption that scheduling changes the monthly quantity is performed. Inspect quote quantities and audit query purchase options. Unknown != zero; zero-valued rows or `price_source: live` alone must not be treated as genuine quotes.

## Evidence paths

- `handles.json`, `setup-receipt.json`, `setup-commands.jsonl`
- `fixtures-manifest.json`, `verification.json`
- `run_acceptance.py`, `setup.py`, `net-helper.go`
- `api-source/cmd/trial-import/{main.go,main_test.go}`
- `run-*/commands.jsonl`: full argv, exit status, stdout/stderr, elapsed time
- `run-*/fixture-results.json`, `summary.json`: 12 regular cases / separate negative control
- `run-*/http-routing.stdout`: transparent local HTTP request/response audit (includes catalog)
- `run-*/served-catalog.stdout`, `database-counts.stdout`, `import.stdout`, `input-contract.json`

## Exact cleanup (ONLY after parent has collected evidence)

```sh
docker rm -f isaac-gcp-verify-77e5e4c2-cli isaac-gcp-verify-77e5e4c2-api isaac-gcp-verify-77e5e4c2-db
docker network rm isaac-gcp-verify-77e5e4c2-net
```

No volume removal needed; none were created. Do not prune Docker or remove shared images. Keep local runtime files as evidence or remove only this runtime directory after review. Stopping/removing DB destroys the imported tmpfs catalog; this is intentional.
