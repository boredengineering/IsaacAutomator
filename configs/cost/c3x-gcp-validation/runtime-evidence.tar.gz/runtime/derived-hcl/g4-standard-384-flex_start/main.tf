terraform {
  required_providers = { "google" = { "source" = "hashicorp/google", "version" = "= 8.2.0" } }
}

provider "google" {
  project = "public-synthetic-no-deployment"
  region = "us-west1"
  zone = "us-west1-c"
}

resource "google_compute_network" "private" {
  name = "synthetic-cost-only"
  auto_create_subnetworks = false
}

resource "google_compute_subnetwork" "private" {
  name = "synthetic-cost-only"
  region = "us-west1"
  ip_cidr_range = "10.70.0.0/24"
  network = "${google_compute_network.private.id}"
  private_ip_google_access = true
}

resource "google_compute_instance" "workstation" {
  name = "synthetic-cost-only"
  machine_type = "g4-standard-384"
  zone = "us-west1-c"
  boot_disk {
    initialize_params {
      image = "ubuntu-os-cloud/ubuntu-2204-lts"
      size = 255
      type = "hyperdisk-balanced"
    }
  }
  guest_accelerator {
    type = "nvidia-rtx-pro-6000"
    count = 8
  }
  network_interface {
    subnetwork = "${google_compute_subnetwork.private.id}"
  }
  scheduling {
    provisioning_model = "FLEX_START"
    on_host_maintenance = "TERMINATE"
    automatic_restart = false
    instance_termination_action = "STOP"
    max_run_duration {
      seconds = 3600
    }
  }
  metadata = { "enable-oslogin" = "TRUE", "block-project-ssh-keys" = "TRUE" }
}

resource "google_compute_router" "private" {
  name = "synthetic-cost-only"
  region = "us-west1"
  network = "${google_compute_network.private.id}"
}

resource "google_compute_router_nat" "private" {
  name = "synthetic-cost-only"
  router = "${google_compute_router.private.name}"
  region = "us-west1"
  nat_ip_allocate_option = "AUTO_ONLY"
  source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"
}

resource "google_storage_bucket" "state_example" {
  name = "synthetic-cost-only-not-a-real-backend"
  location = "US-WEST1"
  uniform_bucket_level_access = true
}

resource "google_artifact_registry_repository" "images" {
  location = "us-west1"
  repository_id = "synthetic-cost-only"
  format = "DOCKER"
}
