package main

import (
 "strings"
 "testing"
)

func TestDecodeRejectsMalformedWithoutEcho(t *testing.T) {
 _, err := decodeProduct([]byte(`{"productHash":"do-not-echo",`))
 if err == nil || strings.Contains(err.Error(), "do-not-echo") { t.Fatal("must return sanitized decode error") }
}
