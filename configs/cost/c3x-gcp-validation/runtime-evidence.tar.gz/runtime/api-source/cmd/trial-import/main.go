// Offline acceptance harness; production pricing and normalization are unchanged.
package main

import (
 "bufio"
 "context"
 "encoding/json"
 "errors"
 "io"
 "log/slog"
 "os"
 "time"

 "github.com/c3xdev/c3x-pricing-api/internal/config"
 "github.com/c3xdev/c3x-pricing-api/internal/db"
)

func decodeProduct(line []byte) (db.Product, error) {
 var p db.Product
 if json.Unmarshal(line, &p) != nil { return p, errors.New("invalid_product_json") }
 return p, nil
}

func main() {
 slog.SetDefault(slog.New(slog.NewTextHandler(io.Discard, nil)))
 counts := map[string]any{"status":"error", "lines":0, "upserted_input_rows":0}
 fail := func(stage string) { counts["error_stage"]=stage; _=json.NewEncoder(os.Stdout).Encode(counts); os.Exit(1) }
 cfg:=config.Load()
 if cfg.Validate()!=nil { fail("config") }
 ctx,cancel:=context.WithTimeout(context.Background(),10*time.Minute); defer cancel()
 d,err:=db.New(ctx,cfg.DatabaseURL,db.PoolOptions{MaxConns:2}); if err!=nil { fail("connect") }; defer d.Close()
 if d.RunMigrations(ctx)!=nil { fail("migrations") }
 f,err:=os.Open("/trial/products.ndjson"); if err!=nil { fail("input_open") }; defer f.Close()
 scanner:=bufio.NewScanner(f); scanner.Buffer(make([]byte,65536),16*1024*1024)
 batch:=make([]db.Product,0,1000); n:=0; inserted:=0
 flush:=func(){ if len(batch)==0{return}; if d.UpsertProducts(ctx,batch)!=nil {fail("upsert")}; inserted+=len(batch); counts["upserted_input_rows"]=inserted; batch=batch[:0] }
 for scanner.Scan(){
  n++; counts["lines"]=n
  p,err:=decodeProduct(scanner.Bytes()); if err!=nil {fail("decode")}
  if p.ProductHash=="" || p.VendorName!="gcp" || p.SKU=="" {fail("identity")}
  batch=append(batch,p); if len(batch)==cap(batch){flush()}
 }
 if scanner.Err()!=nil {fail("input_read")}; if n==0 {fail("empty_input")}; flush()
 count,err:=d.CountProducts(ctx); if err!=nil {fail("count")}
 counts["status"]="ok"; counts["database_products"]=count
 _=json.NewEncoder(os.Stdout).Encode(counts)
}
