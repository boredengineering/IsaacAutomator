package scraper

// Explicit live integration harness: no production pricing/model changes.
import (
 "bytes"
 "compress/gzip"
 "context"
 "crypto/sha256"
 "encoding/hex"
 "encoding/json"
 "errors"
 "fmt"
 "io"
 "net/http"
 "os"
 "path/filepath"
 "strings"
 "testing"
 "time"

 "github.com/c3xdev/c3x-pricing-api/internal/config"
 "github.com/c3xdev/c3x-pricing-api/internal/db"
)

type catalogCaptureTransport struct {
 base http.RoundTripper
 dir string
 calls int
 bytes int64
 pages []map[string]any
}

func (c *catalogCaptureTransport) RoundTrip(r *http.Request) (*http.Response, error) {
 c.calls++
 if c.calls > 160 || c.bytes > 1024*1024*1024 { return nil, errors.New("catalog capture budget exceeded") }
 if r.URL.Scheme != "https" || r.URL.Host != "cloudbilling.googleapis.com" || r.Method != "GET" {
  return nil, errors.New("capture destination refused")
 }
 resp, err := c.base.RoundTrip(r)
 if err != nil { return nil, errors.New("catalog capture transport failed") }
 // Never archive headers, credentials or remote error bodies.
 if resp.StatusCode != http.StatusOK { return resp, nil }
 data, err := io.ReadAll(io.LimitReader(resp.Body, 32*1024*1024+1))
 resp.Body.Close()
 if err != nil || len(data) > 32*1024*1024 { return nil, errors.New("catalog capture page exceeds bound or failed") }
 c.bytes += int64(len(data))
 var page map[string]json.RawMessage
 if json.Unmarshal(data, &page) != nil { return nil, errors.New("catalog capture response is not JSON") }
 var items []json.RawMessage
 kind := "services"
 if b, ok := page["skus"]; ok { kind="skus"; if json.Unmarshal(b,&items)!=nil {return nil,errors.New("invalid SKU list")} } else if json.Unmarshal(page["services"],&items)!=nil {return nil,errors.New("invalid service list")}
 hash:=sha256.Sum256(data)
 filename:=fmt.Sprintf("%03d.json.gz",c.calls)
 f,err:=os.Create(filepath.Join(c.dir,filename)); if err!=nil{return nil,errors.New("capture file create failed")}
 z:=gzip.NewWriter(f)
 _,err=z.Write(data); closeErr:=z.Close(); fileErr:=f.Close()
 if err!=nil || closeErr!=nil || fileErr!=nil{return nil,errors.New("capture file write failed")}
 c.pages=append(c.pages,map[string]any{"file":filename,"path":r.URL.Path,"kind":kind,"records":len(items),"bytes":len(data),"sha256":hex.EncodeToString(hash[:]),"retrieved_at":time.Now().UTC().Format(time.RFC3339),"status":resp.StatusCode})
 resp.Body=io.NopCloser(bytes.NewReader(data))
 return resp,nil
}

func TestLiveGCPValidationCapture(t *testing.T) {
 if os.Getenv("ISAAC_GCP_CATALOG_LIVE")!="1" {t.Skip("explicit live opt-in required")}
 if os.Getenv("GCP_AUTH_MODE")!="adc" || os.Getenv("GCP_API_KEY")!="" {t.Fatal("requires ADC without API key")}
 dir:=os.Getenv("ISAAC_GCP_CATALOG_OUTPUT")
 if dir=="" {t.Fatal("explicit output directory required")}
 if err:=os.MkdirAll(dir,0700); err!=nil {t.Fatal("cannot create output")}
 if _,err:=os.Stat(filepath.Join(dir,"products.ndjson")); !os.IsNotExist(err) {t.Fatal("refusing existing final products file")}
 cfg:=config.Load()
 s:=NewGCPScraper(cfg)
 capture:=&catalogCaptureTransport{base:http.DefaultTransport,dir:dir}
 s.client.Transport=capture
 ctx,cancel:=context.WithTimeout(context.Background(),8*time.Minute); defer cancel()
 summary:=map[string]any{"auth_mode":"adc","quota_project":cfg.GCPQuotaProject,"service_scope":[]string{"Compute Engine","Cloud Storage","Networking","Artifact Registry"},"region_projection":[]string{"us-west1","us-east1","us","global",""},"production_functions":[]string{"Preflight","resolveDiscoverableServices","scrapeService","synthesizeMachineTypes"},"full_gcp_catalog":false,"credentials_archived":false}
 defer func(){
  summary["complete"]=!t.Failed();summary["pages"]=capture.pages;summary["http_calls"]=capture.calls;summary["raw_bytes"]=capture.bytes
  b,err:=json.MarshalIndent(summary,"","  ");if err!=nil{t.Error("summary encode failed");return}
  if os.WriteFile(filepath.Join(dir,"capture-summary.json"),append(b,'\n'),0600)!=nil{t.Error("summary write failed")}
 }()
 if err:=s.Preflight(ctx);err!=nil{t.Fatal(err)}
 discovered,err:=s.resolveDiscoverableServices(ctx);if err!=nil{t.Fatal(err)}
 artifactID:=""
 for name,id:=range discovered{if strings.EqualFold(name,"Artifact Registry"){artifactID=id}}
 if artifactID==""{t.Fatal("Artifact Registry not resolved")}
 targets:=[]struct{name,id string}{{"Compute Engine",gcpServices["Compute Engine"]},{"Cloud Storage",gcpServices["Cloud Storage"]},{"Networking",gcpServices["Networking"]},{"Artifact Registry",artifactID}}
 out,err:=os.Create(filepath.Join(dir,"products.ndjson.partial"));if err!=nil{t.Fatal("product output create failed")};defer out.Close()
 enc:=json.NewEncoder(out)
 regionOK:=func(p db.Product)bool{r:=strings.ToLower(p.Region);return r=="us-west1"||r=="us-east1"||r=="us"||r=="global"||r==""}
 total:=0;serviceCounts:=map[string]int{};var compute []db.Product
 for _,target:=range targets{
  products,err:=s.scrapeService(ctx,target.name,target.id);if err!=nil{t.Fatal(err)}
  count:=0
  for _,product:=range products{
   if !regionOK(product){continue}
   if err:=enc.Encode(product);err!=nil{t.Fatal("product write failed")};count++;total++
   if target.name=="Compute Engine"{compute=append(compute,product)}
  }
  serviceCounts[target.name]=count
  t.Logf("completed public service=%s projected_products=%d",target.name,count)
 }
 synthesized:=s.synthesizeMachineTypes(compute)
 for _,product:=range synthesized{if err:=enc.Encode(product);err!=nil{t.Fatal("synthesized product write failed")};total++}
 if err:=out.Close();err!=nil{t.Fatal("product close failed")}
 if err:=os.Rename(filepath.Join(dir,"products.ndjson.partial"),filepath.Join(dir,"products.ndjson"));err!=nil{t.Fatal("product publish failed")}
 summary["projected_products_by_service"]=serviceCounts;summary["synthesized_products"]=len(synthesized);summary["total_products"]=total
 t.Logf("completed catalog requests=%d projected_products=%d synthesized=%d",capture.calls,total,len(synthesized))
}
